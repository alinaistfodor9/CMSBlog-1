﻿using Sitecore;
using Sitecore.Configuration;
using Sitecore.Data;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Layouts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Capco.Common.UpgradeScripts
{
  public partial class CompareMasterWebContent : System.Web.UI.Page
  {
    private static StringBuilder sbResults = new StringBuilder();
    private static Database masterDb = Factory.GetDatabase("master");
    private static Database webDb = Factory.GetDatabase("web");

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Go_Click(object sender, EventArgs e)
    {
      this.lblResults.Text = string.Empty;
      sbResults = new StringBuilder();
      using (new Sitecore.SecurityModel.SecurityDisabler())
      {
        string rt = this.txtRootId.Text;
        Item root = masterDb.GetItem(rt);
        if (root != null)
        { 
          this.ProcessItem(root);
        }
        else
        {
          this.lblResults.Text += " Root item is null <br/>";

        }

        lblResults.Text = sbResults.ToString();
      }

    }

    /// <summary>
    /// On itm item  copy content from  fromLanguage to toLanguage
    /// </summary>
    private void CompareContent(Item itm)
    {
      try
      {
        var masterItem = itm.Versions.GetLatestVersion();
        if (masterItem.Versions.Count == 0)
          return;

        var webItem = webDb.GetItem(masterItem.ID);

        if (webItem == null)
        {
          sbResults.AppendLine("Item not published: <b>" + masterItem.Paths.FullPath + "</b><br/>");

        }

        if (!string.IsNullOrEmpty(masterItem["__Final Renderings"]))
        {
          if (masterItem["__Final Renderings"] != webItem["__Final Renderings"])
          {
            sbResults.AppendLine("Item final rendering not published: <b>" + masterItem.Paths.FullPath + "</b><br/>");
          }
        }
        else
        {
          if (!string.IsNullOrEmpty(masterItem["__Renderings"]))
          {
            if (masterItem["__Renderings"] != webItem["__Renderings"])
            {
              sbResults.AppendLine("Item rendering not published: <b>" + masterItem.Paths.FullPath + "</b><br/>");
            }
          }
        }

        using (new Sitecore.SecurityModel.SecurityDisabler())
        {
          //if versions doesn't exist on itemFromLang we create a new version and copy content from itemAnotherLang to it

          masterItem.Fields.ReadAll();

          foreach (Sitecore.Data.Fields.Field fldFrom in masterItem.Fields)
          {
            if (fldFrom == null)
            {
              continue;
            }

            if (fldFrom.Name.StartsWith("__"))
            {
              continue;
            }

            if (masterItem[fldFrom.Name] != webItem[fldFrom.Name])
            {
              sbResults.AppendLine("Item field <b>" + fldFrom.Name + "</b> not published: <b>" + masterItem.Paths.FullPath + "</b><br/>");
            }
          }
        }
      }
      catch { }
    }


    private void ProcessItem(Item rt)
    {
      try
      {

        this.CompareContent(rt);


      }
      catch (Exception ex)
      {
        Sitecore.Diagnostics.Log.Info("Erorr at the following at item" + rt.Paths.ContentPath + ex.Message + ex.StackTrace, this);
        this.lblResults.Text += ex.ToString() + " <br/>";
      }

      foreach (Item child in rt.Children)
      {
        this.ProcessItem(child);
      }

    }

  }
}
