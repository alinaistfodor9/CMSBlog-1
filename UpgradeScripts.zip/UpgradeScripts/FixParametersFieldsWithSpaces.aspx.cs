﻿using Sitecore;
using Sitecore.Configuration;
using Sitecore.Data.Fields;
using Sitecore.Data.Items;
using Sitecore.Diagnostics;
using Sitecore.Layouts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace Capco.Common.UpgradeScripts
{
  public partial class FixParametersFieldsWithSpaces : System.Web.UI.Page
  {
    private const string ItemsWithPresentationDetailsQuery =
       "{0}//*[@__Renderings != '' or @__Final Renderings != '']";
    private const string DatabaseName = "master";
    private const string DefaultDeviceId = "{FE5D7FDF-89C0-4D99-9AA3-B5FBD009C9F3}";
    private static string StartItemId = "D95FAE25-50EC-477C-B129-E012A4537D3C";

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    private void OutputResult(Dictionary<Item, List<KeyValuePair<string, string>>> result)
    {
      Response.ContentType = "text/html";

      Response.Write($"<h1>{result.Count} items processed</h1>");
      foreach (var pair in result)
      {
        Response.Write($"<h3>{pair.Key.Paths.FullPath}</h3>");

        foreach (var kvp in pair.Value)
        {
          if (kvp.Key != kvp.Value)
          {
            Response.Write($"<div>{kvp.Key} ==> {kvp.Value}</div>");
          }
        }
      }
    }

    public Dictionary<Item, List<KeyValuePair<string, string>>> Iterate()
    {
      var result = new Dictionary<Item, List<KeyValuePair<string, string>>>();
      var master = Factory.GetDatabase(DatabaseName);
      Item startItem = master.GetItem(StartItemId);
      var items = master.SelectItems(string.Format(ItemsWithPresentationDetailsQuery,
                  startItem.Paths.FullPath));

      var layoutFields = new[] { FieldIDs.LayoutField, FieldIDs.FinalLayoutField };

      foreach (var item in items)
      {
        foreach (var layoutField in layoutFields)
        {
          var changeResult = ChangeLayoutFieldForItem(item, item.Fields[layoutField]);

          if (changeResult.Any())
          {
            if (!result.ContainsKey(item))
            {
              result.Add(item, changeResult);
            }
            else
            {
              result[item].AddRange(changeResult);
            }
          }
        }
      }

      return result;
    }

    private List<KeyValuePair<string, string>> ChangeLayoutFieldForItem(Item currentItem, Field field)
    {

      var result = new List<KeyValuePair<string, string>>();

      string xml = LayoutField.GetFieldValue(field);
      try
      {
        if (!string.IsNullOrWhiteSpace(xml))
        {
          LayoutDefinition details = LayoutDefinition.Parse(xml);

          var device = details.GetDevice(DefaultDeviceId);
          DeviceItem deviceItem = currentItem.Database.Resources.Devices["Default"];

          RenderingReference[] renderings = currentItem.Visualization.GetRenderings(deviceItem, false);

          bool needUpdate = false;
          foreach (RenderingDefinition rendering in device.Renderings)
          {
            if (txtRenderigns.Text.IndexOf(rendering.ItemID.ToString(), StringComparison.CurrentCultureIgnoreCase) >= 0)
            {

              var paramsFields = rendering.Parameters;
              if (paramsFields != null)
              {
                needUpdate = true;
                rendering.Parameters = PascalCase(paramsFields);
              }
            }
          }

          if (needUpdate)
          {
            string newXml = details.ToXml();

            using (new EditContext(currentItem, false, true))
            {
              LayoutField.SetFieldValue(field, newXml);
            }
            result.Add(new KeyValuePair<string, string>(currentItem.ID.ToString(), currentItem.Name));
            //write it to log

          }

        }
      }
      catch (Exception ex)
      {

        Log.Error("ChangeLayoutFieldForItem.Default", ex, "");

      }
      return result;
    }

    private string PascalCase(string str)
    {
      var splitSpaces = str.Split(' ');
      var results = "";
      foreach (var section in splitSpaces)
      {
        results += FirstToUpper(section);
      }
      return results;
    }

    private string FirstToUpper(string lowerWord)
    {
      if (string.IsNullOrWhiteSpace(lowerWord) || string.IsNullOrEmpty(lowerWord))
        return lowerWord;

      return new StringBuilder(lowerWord.Substring(0, 1).ToUpper())
                .Append(lowerWord.Substring(1))
                .ToString();
    }

    protected void Go_Click(object sender, EventArgs e)
    {
      StartItemId = txtRootId.Text;
      var result = Iterate();
      OutputResult(result);
    }
  }
}
